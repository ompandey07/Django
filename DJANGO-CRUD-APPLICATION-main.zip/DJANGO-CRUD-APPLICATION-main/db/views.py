from django.shortcuts import render, redirect
from db.models import Userdata


#*--------------- DJANGO CRUD APPLICATION VIEW ---------------------*#


# This View Handle Add Ange Get Data From HTML Form 
def curd_form (request):
    if request.method == 'GET':
        show_data = Userdata.objects.all()
        return render (request , 'index.html', {'show_data' : show_data})
    else:
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        database = Userdata(first_name = first_name , last_name = last_name )
        database.save()
        return redirect ('curd_form')
    


# This View Handle Delete
def delete (request , id):
    user = Userdata.objects.get(id=id)
    user.delete()
    return redirect ('curd_form')



# This View Handle Delete
def edit(request, id):
    if request.method == 'POST':
        user = Userdata.objects.get(id=id)
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        user.save()
        return redirect('curd_form')
    else:
        value = Userdata.objects.get(id=id)
        return render(request, 'edit.html', {'value': value})



