from django.contrib import admin
from db.models import Userdata


admin.site.register(Userdata)
